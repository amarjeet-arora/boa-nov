package com.model;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.ServiceImpl;

 

public class BankClient {

	public static void main(String[] args) {
		
	 
		
		ConfigurableApplicationContext ctx= new AnnotationConfigApplicationContext(AppConfig.class);
		
		
	 ServiceImpl si= (ServiceImpl)ctx.getBean("si");
		
		System.out.println(si.sayWelcome("Admin"));
		ctx.close();
		
	 
	}
}
