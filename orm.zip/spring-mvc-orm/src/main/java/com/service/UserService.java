package com.service;

import java.util.List;

import com.model.Users;

public interface UserService {
	
	public boolean loginCheck(Users users);
	public List<Users> loadAll();
	public boolean findUser(String uname);
	public void registerUser(Users users);
	public boolean deleteUser(String uname);
	public void updateUser(String name,Users users);

}
