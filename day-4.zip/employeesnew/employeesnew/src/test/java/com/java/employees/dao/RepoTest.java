package com.java.employees.dao;

import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.junit.jupiter.SpringExtension;

import com.java.employees.model.Employee;

@ExtendWith(SpringExtension.class)
@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
public class RepoTest {

	@Autowired
	EmployeeRepository repo;
	@Test
	public void testCreate() {
		Employee emp= new Employee("Anil", "Mehta");
		repo.save(emp);
		Iterable<Employee> emps= repo.findAll();
		Assertions.assertThat(emps).extracting(Employee :: getFirstName).containsOnly("Ani");
		repo.deleteAll();
		Assertions.assertThat(repo.findAll()).isEmpty();
	}
}
