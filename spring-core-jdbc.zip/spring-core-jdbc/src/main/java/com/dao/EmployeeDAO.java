package com.dao;

import java.util.List;

import com.model.Employee;

public interface EmployeeDAO {
	
	public void addEmployee(Employee emp);
	public List<Employee> getAllEmps();

}
