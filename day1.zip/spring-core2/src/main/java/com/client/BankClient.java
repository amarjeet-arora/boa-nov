package com.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.service.CalculatorService;

public class BankClient {

	public static void main(String[] args) {
		
		// initiate the container
		
		ConfigurableApplicationContext ctx= new ClassPathXmlApplicationContext("beans.xml");
		
		
		// load the service class
		
		CalculatorService service=(CalculatorService)ctx.getBean("ser");
		
		// call the business function
		
		System.out.println(service.hashCode());
		ctx.close();
		
	 
	}
}
