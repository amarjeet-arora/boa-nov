package com.service;

import org.springframework.stereotype.Component;

@Component("si")
public class ServiceImpl implements AppService {

	@Override
	public String sayWelcome(String name) {
		// TODO Auto-generated method stub
		return "Welcome " + name;
	}

}
