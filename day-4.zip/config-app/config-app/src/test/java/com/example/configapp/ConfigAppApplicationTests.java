package com.example.configapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConfigAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
