package com.example.springcorejdbc;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringCoreJdbcApplicationTests {

	@Test
	void contextLoads() {
	}

}
