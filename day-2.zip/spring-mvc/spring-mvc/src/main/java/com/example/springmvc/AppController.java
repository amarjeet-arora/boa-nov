package com.example.springmvc;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

@Controller
@RequestMapping("/mainapp")
public class AppController {
	
	@RequestMapping(value = "/welcome",method = RequestMethod.GET)
	@ResponseBody
	public String sayWelcome() {
		return "Welcome to Spring MVC...!";
	}
	
	@RequestMapping(value = "/login",method = RequestMethod.GET)
	 
	public String login() {
		return "login";
	}
	
	@RequestMapping(value = "/login",method = RequestMethod.POST)
	 @ResponseBody
	public String loginValid(@RequestParam("uname") String uname,@RequestParam("pass")String pass) {
		if(uname.equals("admin") && pass.equals("manager")) {
			return "Login Success";
		}
		return "login Failed";
	}
	
	@RequestMapping(value = "/register",method = RequestMethod.GET)
	 
	public String register() {
		return "register";
	}

}
