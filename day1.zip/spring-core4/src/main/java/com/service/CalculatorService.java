package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.model.InterestCalculator;
//@Service("ser")
public class CalculatorService {
	
	//@Autowired
	//@Qualifier("fda")
	private InterestCalculator ic;

	 
	
public CalculatorService(InterestCalculator ic) {
		super();
		this.ic = ic;
	}
public double service(double amount) {
	
	return ic.calculate(amount);
}
public void initCall() {
	System.out.println("called during load");
}
public void destroyCall() {
	System.out.println("called before delete");
}
}
