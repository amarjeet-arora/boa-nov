package com.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.ImportResource;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

import com.model.FDA;
import com.model.SavingAccount;
import com.service.CalculatorService;

@Configuration
@ComponentScan("com")
 public class AppConfig {

	
	@Bean
	@Lazy
	public FDA fixedAccount() {
		return new FDA(5,5.6);
	}
	@Bean
	@Lazy
	 
	public SavingAccount sa() {
		return new SavingAccount(7, 7.8);
	}
	@Bean(name = "ser")
	public CalculatorService service123() {
		return new CalculatorService(fixedAccount());
	}
}
