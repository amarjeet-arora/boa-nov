package com.example.springcorejdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaAuditing;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

import com.model.Employee;
 import com.service.EmployeeService;
 
@SpringBootApplication
@ComponentScan("com")
@EnableJpaRepositories("com")
@EntityScan("com")
public class SpringCoreJdbcApplication {
	
	 

	public static void main(String[] args) {
	ApplicationContext ctx=	SpringApplication.run(SpringCoreJdbcApplication.class, args);
	
	EmployeeService serv=ctx.getBean(EmployeeService.class);
	
	Employee emp1= new Employee("104", "Ashwin2");
 	 
	//serv.addEmployee(emp1);
	List<Employee> data= serv.getAllEmps();
	for(Employee em:data) {
		System.out.println(em);
	}
	}

}
