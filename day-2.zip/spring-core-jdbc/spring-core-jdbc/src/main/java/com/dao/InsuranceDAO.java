package com.dao;

import com.model.Employee;
import com.model.Insurance;

public interface InsuranceDAO {
	
	public void registerInsuranceToEmp(Insurance insurance);

}
