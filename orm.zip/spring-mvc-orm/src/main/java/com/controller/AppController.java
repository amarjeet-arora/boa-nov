package com.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.model.Users;
import com.service.UserService;

@RestController
@RequestMapping("/mainapp")
public class AppController {
	@Autowired
	private UserService service;
	 
 
	 @PostMapping("/login")
	public String loginValid(@ModelAttribute Users users) {
		if(service.loginCheck(users)) {
			return "Login Success";
		}
		return "login Failed";
	}
	
	 
	 @PostMapping("/register")
	public String registerUser(@RequestBody Users users) {
		service.registerUser(users);
		return "user registered";
	}
	@GetMapping("/loadusers")
	 public List<Users>loadAll(){
		 return service.loadAll();
	 }
	@GetMapping("/loadusers/{uname}")
	 public String findUser(@PathVariable String uname){
		if(service.findUser(uname)) {
			return uname + " found";
		}
		return uname + " not found...!";
	 }
	@DeleteMapping("/deleteusers/{uname}")
	 public String deleteUser(@PathVariable String uname){
		if(service.deleteUser(uname)) {
			return uname + " found and deleted";
		}
		return uname + " not found...!";
	 }
	@PutMapping("/updateusers/{uname}")
	 public String updateUser(@PathVariable String uname,@RequestBody Users users){
	service.updateUser(uname,users) ;
			return "user updated";
	 }

}
