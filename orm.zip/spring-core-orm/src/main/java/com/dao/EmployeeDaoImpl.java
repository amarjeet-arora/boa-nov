package com.dao;

import java.util.List;
import java.util.Optional;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.model.Employee;
import com.repo.UserRepo;

@Repository
public class EmployeeDaoImpl  implements EmployeeDAO   {
	@Autowired
	 private UserRepo repo;
	
	 

	@Override
	public void addEmployee(Employee emp) {
		 repo.save(emp);
		
	}

	//@Override
	public List<Employee> getAllEmps() {
		return (List<Employee>)repo.findAll();
	}

	@Override
	public boolean findEmp(String empId) {
	Optional<Employee>data=	repo.findById(empId);
	if(data.isPresent()) {
		return true;
	}
	return false;
	

}}
