package com.example.springcorejdbc;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;

import com.model.Employee;
import com.model.Insurance;
import com.service.EmployeeService;
import com.service.InsuranceService;

@SpringBootApplication
@ComponentScan("com")
public class SpringCoreJdbcApplication {
	
	 

	public static void main(String[] args) {
	ApplicationContext ctx=	SpringApplication.run(SpringCoreJdbcApplication.class, args);
	
	InsuranceService serv=ctx.getBean(InsuranceService.class);
	
	Employee emp1= new Employee("103", "Ashwin2");
	Insurance ins=new Insurance("103","Family Floater", 100000);
	 
	serv.attachEmpToInsu(emp1, ins);
	}

}
