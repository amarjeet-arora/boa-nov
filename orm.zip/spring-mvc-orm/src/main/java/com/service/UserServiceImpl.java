package com.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.model.Users;
import com.repo.UserRepo;

@Service
public class UserServiceImpl implements UserService{
	@Autowired
	private UserRepo repo;
	List<Users> lst= new ArrayList<Users>();
	@Override
	public boolean loginCheck(Users users) {
		 if(users.getUname().equals("admin") && users.getPass().equals("manager")) {
			 return true;
		 }
		return false;
	}

	@Override
	public List<Users> loadAll() {
		// TODO Auto-generated method stub
		return lst;
	}

	@Override
	public boolean findUser(String uname) {
		for(Users user:lst) {
			if(user.getUname().equals(uname)) {
				System.out.println(user.getEmail());
				return true;
			}
		}
		return false;
	}

	@Override
	public void registerUser(Users users) {
		lst.add(users);
		
	}

	@Override
	public boolean deleteUser(String uname) {
		for(Users user:lst) {
			if(user.getUname().equals(uname)) {
				 lst.remove(user);
				return true;
			}
		}
		return false;
	}

	@Override
	public void updateUser(String name, Users users) {
		// TODO Auto-generated method stub
		
	}

}
