package com.service;

public interface AppService {
	
	public String sayWelcome(String name);

}
