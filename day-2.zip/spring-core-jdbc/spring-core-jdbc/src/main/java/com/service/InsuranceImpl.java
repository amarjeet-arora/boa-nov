package com.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.dao.EmployeeDAO;
import com.dao.InsuranceDAO;
import com.model.Employee;
import com.model.Insurance;
@Service
public class InsuranceImpl implements InsuranceService{
	@Autowired
	private EmployeeDAO employeeDAO;
	@Autowired
	private InsuranceDAO insuranceDAO;

	@Override
	@Transactional
	public void attachEmpToInsu(Employee employee, Insurance insurance) {
		 employeeDAO.addEmployee(employee);
		 if(employee.getEmpId().equals("103")) throw new RuntimeException("something went wrong...!");
		 insuranceDAO.registerInsuranceToEmp(insurance);
		
	}

}
