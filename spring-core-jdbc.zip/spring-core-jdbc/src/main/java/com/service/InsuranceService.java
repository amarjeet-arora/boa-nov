package com.service;

import com.model.Employee;
import com.model.Insurance;

public interface InsuranceService {
public void attachEmpToInsu(Employee employee,Insurance insurance);
}
