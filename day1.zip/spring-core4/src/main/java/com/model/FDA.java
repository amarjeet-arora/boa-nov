package com.model;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

 
public class FDA implements InterestCalculator {

	 
	private int duration;
 
	private double roi;

	 
	public FDA(int duration, double roi) {
		super();
		this.duration = duration;
		this.roi = roi;
	}


	@Override
	public double calculate(double amount) {
		// TODO Auto-generated method stub
		return amount*roi/duration;
	}
	 
}
