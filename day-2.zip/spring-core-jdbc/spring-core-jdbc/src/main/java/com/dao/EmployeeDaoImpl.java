package com.dao;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.support.JdbcDaoSupport;
import org.springframework.stereotype.Repository;

import com.model.Employee;

@Repository
public class EmployeeDaoImpl extends JdbcDaoSupport implements EmployeeDAO   {
	
	@Autowired
	DataSource dataSource;
	
	@PostConstruct
	public void loadDB() {
		setDataSource(dataSource);
	}

	@Override
	public void addEmployee(Employee emp) {
		 String insertData="insert into employee(empId,empName) values(?,?)";
		 getJdbcTemplate().update(insertData,new Object[] {emp.getEmpId(),emp.getEmpName()});
		
	}

	@Override
	public List<Employee> getAllEmps() {
		 String query ="select * from employee";
		List<Employee> data=  getJdbcTemplate().query(query, BeanPropertyRowMapper.newInstance(Employee.class));
		return data;
		
	}
	

}
